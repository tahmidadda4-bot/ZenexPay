import 'dart:io';
import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import '../services/supabase_service.dart';
import '../services/network_error.dart';

class SubmissionsPage extends StatefulWidget {
  const SubmissionsPage({super.key});

  @override
  State<SubmissionsPage> createState() => _SubmissionsPageState();
}

class _SubmissionsPageState extends State<SubmissionsPage> {
  late Future<List<Map<String, dynamic>>> future;

  @override
  void initState() {
    super.initState();
    future = SupabaseService.submissions();
  }

  Future<void> _reload() async {
    setState(() => future = SupabaseService.submissions());
    await future;
  }

  Future<void> _open(Map<String, dynamic> row) async {
    final status = '${row['status'] ?? 'pending'}';
    if (status == 'screenshot_requested') {
      await _upload(row);
      return;
    }
    final task = row['tasks'];
    final title = task is Map ? '${task['title'] ?? 'Task'}' : 'Task submission';
    await showModalBottomSheet(
      context: context,
      showDragHandle: true,
      builder: (_) => SafeArea(
        child: Padding(
          padding: const EdgeInsets.fromLTRB(20, 8, 20, 25),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(title, style: const TextStyle(fontSize: 21, fontWeight: FontWeight.w900)),
              const SizedBox(height: 12),
              _Badge(status),
              const SizedBox(height: 16),
              if ('${row['proof_text'] ?? ''}'.trim().isNotEmpty) ...[
                const Text('Your submission', style: TextStyle(fontWeight: FontWeight.w900)),
                const SizedBox(height: 6),
                Text('${row['proof_text']}'),
                const SizedBox(height: 14),
              ],
              if ('${row['rejection_reason'] ?? ''}'.trim().isNotEmpty) ...[
                const Text('Reviewer note', style: TextStyle(fontWeight: FontWeight.w900)),
                const SizedBox(height: 6),
                Text('${row['rejection_reason']}'),
              ],
            ],
          ),
        ),
      ),
    );
  }

  Future<void> _upload(Map<String, dynamic> row) async {
    final ok = await showDialog<bool>(
      context: context,
      builder: (_) => AlertDialog(
        title: const Text('Screenshot required'),
        content: Text('${row['screenshot_reason'] ?? 'The reviewer requested a screenshot as additional proof.'}'),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context, false), child: const Text('Later')),
          FilledButton.icon(
            onPressed: () => Navigator.pop(context, true),
            icon: const Icon(Icons.photo_camera_outlined),
            label: const Text('Choose screenshot'),
          ),
        ],
      ),
    );
    if (ok != true) return;
    final image = await ImagePicker().pickImage(source: ImageSource.gallery, imageQuality: 82, maxWidth: 1800);
    if (image == null) return;
    try {
      if (mounted) {
        showDialog(
          context: context,
          barrierDismissible: false,
          builder: (_) => const Center(child: CircularProgressIndicator()),
        );
      }
      await SupabaseService.uploadScreenshot(submissionId: '${row['id']}', file: File(image.path));
      if (mounted) {
        Navigator.of(context, rootNavigator: true).pop();
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Screenshot submitted for review.')),
        );
        await _reload();
      }
    } catch (e) {
      if (mounted) {
        Navigator.of(context, rootNavigator: true).pop();
        ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(friendlyError(e))));
      }
    }
  }

  @override
  Widget build(BuildContext context) => Scaffold(
        appBar: AppBar(
          title: const Text('My Submissions', style: TextStyle(fontWeight: FontWeight.w900)),
          actions: [IconButton(onPressed: _reload, icon: const Icon(Icons.refresh_rounded))],
        ),
        body: FutureBuilder<List<Map<String, dynamic>>>(
          future: future,
          builder: (context, s) {
            if (s.connectionState != ConnectionState.done) {
              return const Center(child: CircularProgressIndicator());
            }
            if (s.hasError) return Center(child: Text(friendlyError(s.error!)));
            final rows = s.data ?? [];
            if (rows.isEmpty) {
              return RefreshIndicator(
                onRefresh: _reload,
                child: ListView(
                  physics: const AlwaysScrollableScrollPhysics(),
                  children: const [
                    SizedBox(height: 180),
                    Icon(Icons.inbox_rounded, size: 58),
                    SizedBox(height: 12),
                    Center(child: Text('No submissions yet.', style: TextStyle(fontWeight: FontWeight.w800))),
                  ],
                ),
              );
            }
            return RefreshIndicator(
              onRefresh: _reload,
              child: ListView.separated(
                physics: const AlwaysScrollableScrollPhysics(),
                padding: const EdgeInsets.fromLTRB(16, 10, 16, 30),
                itemCount: rows.length,
                separatorBuilder: (_, __) => const SizedBox(height: 10),
                itemBuilder: (_, i) {
                  final r = rows[i];
                  final task = r['tasks'];
                  final title = task is Map ? '${task['title'] ?? 'Task'}' : 'Task submission';
                  final status = '${r['status'] ?? 'pending'}';
                  final v = statusVisual(status);
                  return Container(
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(22),
                      border: Border.all(color: v.foreground.withOpacity(.12)),
                      color: Theme.of(context).colorScheme.surface,
                    ),
                    child: InkWell(
                      onTap: () => _open(r),
                      borderRadius: BorderRadius.circular(22),
                      child: Padding(
                        padding: const EdgeInsets.all(15),
                        child: Column(
                          children: [
                            Row(
                              children: [
                                Container(
                                  width: 44,
                                  height: 44,
                                  decoration: BoxDecoration(
                                    color: v.background,
                                    borderRadius: BorderRadius.circular(14),
                                  ),
                                  child: Icon(v.icon, color: v.foreground),
                                ),
                                const SizedBox(width: 12),
                                Expanded(
                                  child: Text(
                                    title,
                                    maxLines: 2,
                                    overflow: TextOverflow.ellipsis,
                                    style: const TextStyle(fontWeight: FontWeight.w900),
                                  ),
                                ),
                                _Badge(status),
                              ],
                            ),
                            if (status == 'screenshot_requested') ...[
                              const SizedBox(height: 13),
                              SizedBox(
                                width: double.infinity,
                                child: FilledButton.icon(
                                  onPressed: () => _upload(r),
                                  icon: const Icon(Icons.photo_camera_outlined),
                                  label: const Text('Upload requested screenshot'),
                                ),
                              ),
                            ],
                            if (status == 'screenshot_submitted') ...[
                              const SizedBox(height: 10),
                              Align(
                                alignment: Alignment.centerLeft,
                                child: Text(
                                  'Screenshot submitted • waiting for review',
                                  style: TextStyle(
                                    color: Theme.of(context).colorScheme.primary,
                                    fontSize: 12,
                                    fontWeight: FontWeight.w700,
                                  ),
                                ),
                              ),
                            ],
                          ],
                        ),
                      ),
                    ),
                  );
                },
              ),
            );
          },
        ),
      );
}

class _Badge extends StatelessWidget {
  final String status;
  const _Badge(this.status);

  @override
  Widget build(BuildContext c) {
    final v = statusVisual(status);
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 9, vertical: 6),
      decoration: BoxDecoration(color: v.background, borderRadius: BorderRadius.circular(30)),
      child: Text(
        v.label,
        style: TextStyle(color: v.foreground, fontSize: 10, fontWeight: FontWeight.w900),
      ),
    );
  }
}

class StatusVisual {
  final String label;
  final IconData icon;
  final Color background, foreground;
  const StatusVisual(this.label, this.icon, this.background, this.foreground);
}

StatusVisual statusVisual(String s) {
  switch (s.toLowerCase()) {
    case 'approved':
      return const StatusVisual('Approved', Icons.check_circle, Color(0xFFE7F8EE), Color(0xFF087443));
    case 'rejected':
      return const StatusVisual('Rejected', Icons.cancel, Color(0xFFFFE9E9), Color(0xFFB42318));
    case 'screenshot_requested':
      return const StatusVisual(
        'Proof needed',
        Icons.photo_camera_outlined,
        Color(0xFFFFF4D6),
        Color(0xFF8A5A00),
      );
    case 'screenshot_submitted':
      return const StatusVisual(
        'Proof sent',
        Icons.cloud_done_outlined,
        Color(0xFFE8F0FF),
        Color(0xFF175CD3),
      );
    default:
      return const StatusVisual(
        'Pending',
        Icons.hourglass_top_rounded,
        Color(0xFFF2F4F7),
        Color(0xFF475467),
      );
  }
}
